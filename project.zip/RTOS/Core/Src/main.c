/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "FreeRTOS.h"
#include "task.h"

/* --- HAL handles ---------------------------------------------------------- */
UART_HandleTypeDef huart2;

/* ---------- RTOS / traffic types ---------- */
typedef enum
{
    DENSITY_NONE = 0,
    DENSITY_LOW  = 1,
    DENSITY_HIGH = 2
} density_t;

/* Latest density per lane: index 0..2 => L1..3 */
volatile density_t g_laneDensity[3] = { DENSITY_NONE, DENSITY_NONE, DENSITY_NONE };

/* ---------- Pin aliases (IR + LEDs) ---------- */
/* IR sensors: 2 per lane
   Lane1: A0 (high), A1 (low)
   Lane2: A2 (high), B0 (low)
   Lane3: C1 (high), C0 (low)
 */

#define L1_HIGH_GPIO_Port GPIOA
#define L1_HIGH_Pin       GPIO_PIN_0   /* A0 */
#define L1_LOW_GPIO_Port  GPIOA
#define L1_LOW_Pin        GPIO_PIN_1   /* A1 */

#define L2_HIGH_GPIO_Port GPIOA
#define L2_HIGH_Pin       GPIO_PIN_4   /* A2 */
#define L2_LOW_GPIO_Port  GPIOB
#define L2_LOW_Pin        GPIO_PIN_0   /* B0 */

#define L3_HIGH_GPIO_Port GPIOC
#define L3_HIGH_Pin       GPIO_PIN_1   /* C1 */
#define L3_LOW_GPIO_Port  GPIOC
#define L3_LOW_Pin        GPIO_PIN_0   /* C0 */

#define IR_ACTIVE(raw)   ((raw) == 0)   /* assuming active LOW sensors */

/* LEDs: red / blue / green per lane */
#define L1_RED_GPIO_Port    GPIOA
#define L1_RED_Pin          GPIO_PIN_10  /* D2  */
#define L1_BLUE_GPIO_Port   GPIOB
#define L1_BLUE_Pin         GPIO_PIN_3   /* D3  */
#define L1_GREEN_GPIO_Port  GPIOB
#define L1_GREEN_Pin        GPIO_PIN_5   /* D4  */

#define L2_RED_GPIO_Port    GPIOB
#define L2_RED_Pin          GPIO_PIN_4   /* D5  */
#define L2_BLUE_GPIO_Port   GPIOB
#define L2_BLUE_Pin         GPIO_PIN_10  /* D6  */
#define L2_GREEN_GPIO_Port  GPIOA
#define L2_GREEN_Pin        GPIO_PIN_8   /* D7  */

#define L3_RED_GPIO_Port    GPIOA
#define L3_RED_Pin          GPIO_PIN_9   /* D8  */
#define L3_BLUE_GPIO_Port   GPIOC
#define L3_BLUE_Pin         GPIO_PIN_7   /* D9  */
#define L3_GREEN_GPIO_Port  GPIOB
#define L3_GREEN_Pin        GPIO_PIN_6   /* D10 */

/* ---------- LED helper ---------- */
typedef enum
{
    LANE_LED_RED = 0,
    LANE_LED_BLUE,
    LANE_LED_GREEN
} lane_led_state_t;

/* Function prototypes -------------------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);

/* RTOS task prototypes */
static void master_task(void *parameters);
static void lane1_task(void *parameters);
static void lane2_task(void *parameters);
static void lane3_task(void *parameters);

/* Local helpers */
static void print_str(const char *s);
static void set_lane_led(uint8_t lane, lane_led_state_t state);
static density_t read_lane_density(uint8_t laneIndex);
static uint8_t select_next_nonempty_lane(uint8_t last_green);

/* Redirect printf to USART2 (optional) */
int _write(int file, char *ptr, int len)
{
    (void)file;
    HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}

static void print_str(const char *s)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)s, strlen(s), HAL_MAX_DELAY);
}

/* Read density of lane 0..2 from its two IR pins */
static density_t read_lane_density(uint8_t laneIndex)
{
    uint8_t rawH = 1, rawL = 1;

    if (laneIndex == 0)
    {
        rawH = HAL_GPIO_ReadPin(L1_HIGH_GPIO_Port, L1_HIGH_Pin) ? 1 : 0;
        rawL = HAL_GPIO_ReadPin(L1_LOW_GPIO_Port,  L1_LOW_Pin)  ? 1 : 0;
    }
    else if (laneIndex == 1)
    {
        rawH = HAL_GPIO_ReadPin(L2_HIGH_GPIO_Port, L2_HIGH_Pin) ? 1 : 0;
        rawL = HAL_GPIO_ReadPin(L2_LOW_GPIO_Port,  L2_LOW_Pin)  ? 1 : 0;
    }
    else /* laneIndex == 2 */
    {
        rawH = HAL_GPIO_ReadPin(L3_HIGH_GPIO_Port, L3_HIGH_Pin) ? 1 : 0;
        rawL = HAL_GPIO_ReadPin(L3_LOW_GPIO_Port,  L3_LOW_Pin)  ? 1 : 0;
    }

    uint8_t h_act = IR_ACTIVE(rawH);
    uint8_t l_act = IR_ACTIVE(rawL);

    if (h_act && l_act)
        return DENSITY_HIGH;
    if (h_act || l_act)
        return DENSITY_LOW;
    return DENSITY_NONE;
}

/* Choose next lane with NON-ZERO density, starting after last_green */
static uint8_t select_next_nonempty_lane(uint8_t last_green)
{
    density_t max = DENSITY_NONE;
    for (uint8_t i = 0; i < 3; i++)
        if (g_laneDensity[i] > max) max = g_laneDensity[i];

    if (max == DENSITY_NONE)
    {
        /* No lane has cars: keep same; caller will handle empty case */
        return last_green;
    }

    for (uint8_t off = 1; off <= 3; off++)
    {
        uint8_t idx = (last_green + off) % 3;
        if (g_laneDensity[idx] == max)
            return idx;
    }
    return last_green;
}

/* Set lane LEDs: exactly one color ON per lane, others OFF */
static void set_lane_led(uint8_t lane, lane_led_state_t state)
{
    GPIO_TypeDef *rPort, *bPort, *gPort;
    uint16_t rPin, bPin, gPin;

    if (lane == 1)
    {
        rPort = L1_RED_GPIO_Port;   rPin = L1_RED_Pin;
        bPort = L1_BLUE_GPIO_Port;  bPin = L1_BLUE_Pin;
        gPort = L1_GREEN_GPIO_Port; gPin = L1_GREEN_Pin;
    }
    else if (lane == 2)
    {
        rPort = L2_RED_GPIO_Port;   rPin = L2_RED_Pin;
        bPort = L2_BLUE_GPIO_Port;  bPin = L2_BLUE_Pin;
        gPort = L2_GREEN_GPIO_Port; gPin = L2_GREEN_Pin;
    }
    else /* lane == 3 */
    {
        rPort = L3_RED_GPIO_Port;   rPin = L3_RED_Pin;
        bPort = L3_BLUE_GPIO_Port;  bPin = L3_BLUE_Pin;
        gPort = L3_GREEN_GPIO_Port; gPin = L3_GREEN_Pin;
    }

    HAL_GPIO_WritePin(rPort, rPin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(bPort, bPin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(gPort, gPin, GPIO_PIN_RESET);

    if (state == LANE_LED_RED)   HAL_GPIO_WritePin(rPort, rPin, GPIO_PIN_SET);
    if (state == LANE_LED_BLUE)  HAL_GPIO_WritePin(bPort, bPin, GPIO_PIN_SET);
    if (state == LANE_LED_GREEN) HAL_GPIO_WritePin(gPort, gPin, GPIO_PIN_SET);
}

/* ====================== RTOS TASKS ====================== */

/* Lane1 task: periodically update density for lane 0 */
static void lane1_task(void *parameters)
{
    (void)parameters;
    for (;;)
    {
        g_laneDensity[0] = read_lane_density(0);
        vTaskDelay(pdMS_TO_TICKS(100));   /* 100 ms sampling */
    }
}

/* Lane2 task: periodically update density for lane 1 */
static void lane2_task(void *parameters)
{
    (void)parameters;
    for (;;)
    {
        g_laneDensity[1] = read_lane_density(1);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

/* Lane3 task: periodically update density for lane 2 */
static void lane3_task(void *parameters)
{
    (void)parameters;
    for (;;)
    {
        g_laneDensity[2] = read_lane_density(2);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

/* Master task: uses densities, controls LEDs, prints once per second */
static void master_task(void *parameters)
{
    (void)parameters;
    char buf[160];

    print_str("\r\nTraffic RTOS started (master + 3 lane tasks)\r\n");

    uint8_t current_green = 0; /* index 0..2 => lane1..3 */
    uint8_t current_blue  = 1;

    uint32_t phase_remaining_s   = 0;   /* time left in current phase */
    uint32_t green_continuous_s  = 0;   /* how long same lane has been GREEN */

    TickType_t last_wake = xTaskGetTickCount();

    for (;;)
    {
        /* 1 Hz deterministic tick for master logic */
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(1000));

        /* Snapshot densities */
        density_t d0 = g_laneDensity[0];
        density_t d1 = g_laneDensity[1];
        density_t d2 = g_laneDensity[2];

        uint8_t all_empty =
            (d0 == DENSITY_NONE &&
             d1 == DENSITY_NONE &&
             d2 == DENSITY_NONE);

        /* --- Start new phase when countdown hits 0 --- */
        if (phase_remaining_s == 0)
        {
            if (all_empty)
            {
                /* All lanes empty: round-robin, 3s each */
                current_green = (current_green + 1) % 3;
                current_blue  = (current_green + 1) % 3;
                phase_remaining_s  = 3;
                green_continuous_s = 0;   /* reset because we changed lane */
            }
            else
            {
                /* At least one lane has density: enforce 10s max for same GREEN if others also have density */
                uint8_t any_other_has_density = 0;
                for (uint8_t i = 0; i < 3; i++)
                {
                    if (i != current_green && g_laneDensity[i] > DENSITY_NONE)
                    {
                        any_other_has_density = 1;
                        break;
                    }
                }

                uint8_t new_green = current_green;

                /* Force switch if green has been ON >=10s and some other lane has density */
                if (any_other_has_density && green_continuous_s >= 10)
                {
                    density_t best_d = DENSITY_NONE;
                    uint8_t   best_i = current_green;

                    for (uint8_t i = 0; i < 3; i++)
                    {
                        if (i == current_green) continue;
                        if (g_laneDensity[i] > best_d)
                        {
                            best_d = g_laneDensity[i];
                            best_i = i;
                        }
                    }

                    if (best_d > DENSITY_NONE)
                    {
                        new_green = best_i;
                    }
                    else
                    {
                        /* fallback: highest non-empty by helper */
                        new_green = select_next_nonempty_lane(current_green);
                    }
                }
                else
                {
                    /* Normal selection: highest-density lane */
                    new_green = select_next_nonempty_lane(current_green);
                }

                /* If green lane changed, reset continuous counter */
                if (new_green != current_green)
                {
                    current_green      = new_green;
                    green_continuous_s = 0;
                }

                /* BLUE = some other lane with density if possible */
                uint8_t next = (current_green + 1) % 3;
                if (g_laneDensity[next] == DENSITY_NONE)
                {
                    uint8_t found = 0;
                    for (uint8_t off = 1; off <= 3; off++)
                    {
                        uint8_t idx = (current_green + off) % 3;
                        if (idx != current_green && g_laneDensity[idx] > DENSITY_NONE)
                        {
                            next  = idx;
                            found = 1;
                            break;
                        }
                    }
                    if (!found)
                    {
                        next = (current_green + 1) % 3;
                    }
                }
                current_blue = next;

                /* GREEN time based on density of the GREEN lane */
                density_t d = g_laneDensity[current_green];
                if (d == DENSITY_HIGH)
                    phase_remaining_s = 5;
                else if (d == DENSITY_LOW)
                    phase_remaining_s = 3;
                else
                    phase_remaining_s = 1;  /* rare: green lane empty while others have density */
            }

            /* Apply LED outputs: one GREEN, one BLUE, others RED */
            set_lane_led(1, LANE_LED_RED);
            set_lane_led(2, LANE_LED_RED);
            set_lane_led(3, LANE_LED_RED);

            set_lane_led(current_green + 1, LANE_LED_GREEN);
            set_lane_led(current_blue  + 1, LANE_LED_BLUE);
        }

        /* Print status once per second (same format as before) */
        snprintf(buf, sizeof(buf),
                 "dens[L1,L2,L3]=[%u,%u,%u], GREEN=L%u, BLUE=L%u, remain=%lu s\r\n",
                 (unsigned)g_laneDensity[0],
                 (unsigned)g_laneDensity[1],
                 (unsigned)g_laneDensity[2],
                 (unsigned)(current_green + 1),
                 (unsigned)(current_blue  + 1),
                 (unsigned long)phase_remaining_s);
        print_str(buf);

        /* Countdown and continuous green timer update */
        if (phase_remaining_s > 0)
            phase_remaining_s--;

        if (all_empty)
        {
            green_continuous_s = 0;
        }
        else
        {
            green_continuous_s++;  /* same lane stayed green for another 1s tick */
        }
    }
}

/* ====================== MAIN ====================== */

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();

    /* Initial LEDs all RED */
    set_lane_led(1, LANE_LED_RED);
    set_lane_led(2, LANE_LED_RED);
    set_lane_led(3, LANE_LED_RED);

    /* Create tasks:
       - master: higher priority (2) for timing
       - lane tasks: lower priority (1) just sampling sensors
    */
    xTaskCreate(master_task, "master", 256, NULL, 2, NULL);
    xTaskCreate(lane1_task,  "lane1",  256, NULL, 1, NULL);
    xTaskCreate(lane2_task,  "lane2",  256, NULL, 1, NULL);
    xTaskCreate(lane3_task,  "lane3",  256, NULL, 1, NULL);

    vTaskStartScheduler();

    /* Should never reach here */
    while (1)
    {
    }
}

/* ====================== HAL INIT CODE ====================== */

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM            = 16;
    RCC_OscInitStruct.PLL.PLLN            = 336;
    RCC_OscInitStruct.PLL.PLLP            = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ            = 2;
    RCC_OscInitStruct.PLL.PLLR            = 2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* IR inputs: pull-up */
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;

    GPIO_InitStruct.Pin = L1_HIGH_Pin;
    HAL_GPIO_Init(L1_HIGH_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L1_LOW_Pin;
    HAL_GPIO_Init(L1_LOW_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L2_HIGH_Pin;
    HAL_GPIO_Init(L2_HIGH_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L2_LOW_Pin;
    HAL_GPIO_Init(L2_LOW_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L3_HIGH_Pin;
    HAL_GPIO_Init(L3_HIGH_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L3_LOW_Pin;
    HAL_GPIO_Init(L3_LOW_GPIO_Port, &GPIO_InitStruct);

    /* LED outputs */
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

    GPIO_InitStruct.Pin = L1_RED_Pin;
    HAL_GPIO_Init(L1_RED_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = L1_BLUE_Pin;
    HAL_GPIO_Init(L1_BLUE_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = L1_GREEN_Pin;
    HAL_GPIO_Init(L1_GREEN_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L2_RED_Pin;
    HAL_GPIO_Init(L2_RED_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = L2_BLUE_Pin;
    HAL_GPIO_Init(L2_BLUE_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = L2_GREEN_Pin;
    HAL_GPIO_Init(L2_GREEN_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = L3_RED_Pin;
    HAL_GPIO_Init(L3_RED_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = L3_BLUE_Pin;
    HAL_GPIO_Init(L3_BLUE_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = L3_GREEN_Pin;
    HAL_GPIO_Init(L3_GREEN_GPIO_Port, &GPIO_InitStruct);
}

/* Period elapsed callback (TIM6 from CubeMX timebase) */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
    {
        HAL_IncTick();
    }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
}
#endif /* USE_FULL_ASSERT */
